var config = {
  MY_KEY : '123456',
  SECRET_KEY : '56789',
  KEY_2 : '101010',
  // insert your key here
  webster : "67cacd16-20eb-4108-9911-a59316b3ba97",
  edamam : "f4c70c373b3b4086dbca855aba56f666",
  YTKEY : 'AIzaSyB5uc3kvgwFqbvoyvtu_gPuBFYexXXIBzc',
  MirrWebKEY : '67cacd16-20eb-4108-9911-a59316b3ba97',
  edam_ID : "a79ef939",
  edam_KEY : "f4c70c373b3b4086dbca855aba56f666"

  
  // call for the key from this file by doing config._______
  // example: config.MY_KEY
}

config.YTKEY